#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>

unsigned long long n, last, media;
pthread_barrier_t barr;

void *sleepThread(void *argp) {
     pthread_barrier_wait(&barr);
     sleep(5);
     last = n;
}

void *calcThread(void *argp) {
     pthread_barrier_wait(&barr);
     for (n = 1; n != 0; n++)
	  ;
}

int main(void) {
     pthread_t t1, t2;
     int rc, i;
     pthread_barrier_init(&barr, NULL, 3);
     for (i = 0; i < 8; i++) {
	  last = 0;
	  rc = pthread_create(&t1, NULL, sleepThread, NULL);
	  rc = pthread_create(&t2, NULL, calcThread, NULL);
	  pthread_barrier_wait(&barr);
	  rc = pthread_join(t1, NULL);
	  rc = pthread_cancel(t2);
	  printf("%llu\n", last);
	  media += (last >> 3);
     }
     printf("media=%llu\n", media);
     return 0;
}
