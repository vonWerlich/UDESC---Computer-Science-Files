#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#define _GNU_SOURCE
#include <pthread.h>

static char s1[] = "prog1";
static char s2[] = "prog2";
static char s3[] = "prog3";

/* processo memory-bound */
void prog1(void) {
     unsigned long long int tam, i, n, pgsz, *p, freq;
     int j;
     struct timespec tsleep;

     pgsz = getpagesize();
     /* n = atoi(argv[1]); */
     /* freq = atoi(argv[2]); */
     n = (1<<21);
     freq = 20000000;
     tsleep.tv_sec = 0;
     tsleep.tv_nsec = 1000000000L/freq;
     tam = n*pgsz;
     /* printf("Alocando %llu paginas de %llu bytes (%llu bytes total)\n", n,  */
     /* 	    pgsz, tam); */
     p = (unsigned long long int *)malloc(tam);
     if (p == NULL) {
	  fprintf(stderr, "erro no malloc(), abortando execucao\n");
	  exit(1);
     }
     /* printf("Sujando %llu pags/s (tempo de sleep=%lu ns)\n", freq,  */
     /* 	    tsleep.tv_nsec); */
     for (;;) {
	  unsigned long long int r = random();
	  for (i = 0; i < n; i++) {
	       for (j = 0; j < 4; j++) {
		    p[(i*pgsz + j*pgsz/4)/sizeof(unsigned long long int)] = r+j;
	       }
	       nanosleep(&tsleep, NULL);
	       r += 4;
	  }
     }
}

/* processo faz nada */
void prog2(void) {
     unsigned long i;
     for (i = 1; i != 0; i++)
	  sleep(1);
}

/* processo CPU-bound */
void prog3(void) {
     unsigned long i, j;
     for (i = 1; i != 0; i++)
	  for (j = 0; j < 10; j++)
	       ;
}

int main(int argc, char *argv[]) {
     pid_t f1, f2, f3;
     f1 = fork();
     if (f1 == 0) {
	  /* ver https://stackoverflow.com/a/55584492/737303 */
	  pthread_setname_np(pthread_self(), s1);
	  prog1();
	  return 0;
     } 
     f2 = fork();
     if (f2 == 0) {
	  pthread_setname_np(pthread_self(), s2);
	  prog2();
	  return 0;
     }
     f3 = fork();
     if (f3 == 0) {
	  pthread_setname_np(pthread_self(), s3);
	  prog3();
	  return 0;
     } else {
	  printf("PIDs=%u,%u,%u,%u\n", getpid(), f1, f2, f3);
	  waitpid(f1, NULL, 0);
	  waitpid(f2, NULL, 0);
	  waitpid(f3, NULL, 0);
     }
     return 0;
}
