Arquivo zip gerado em: 21/07/2021 08:00:15 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Distância de um valor de valores de um vetor