Arquivo zip gerado em: 16/07/2021 20:47:51 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Encontra números primos em vetor